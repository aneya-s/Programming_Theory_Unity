using UnityEngine;

public class TaxiStand : Stand
{
   

}
