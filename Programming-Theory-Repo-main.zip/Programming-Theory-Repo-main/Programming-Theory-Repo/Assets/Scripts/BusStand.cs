using UnityEngine;

public class BusStand : Stand
{


}
